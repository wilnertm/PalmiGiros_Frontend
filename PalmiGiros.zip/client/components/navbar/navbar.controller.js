'use strict';

 class NavbarController{
   constructor(AuthService,usuariosService,$auth){
    this.menu = [{
     'title': 'Home',
     'state': 'main'
   }];

   this.isCollapsed = true;

   this.AuthService = AuthService;
   this.usuariosService = usuariosService;
   this.$auth = $auth;


  }
$onInit(){
  if (this.$auth.isAuthenticated()) {
    this.usuariosService.get({id:this.$auth.getPayload().sub}).$promise
    .then(response=>{
      this.user=response;
      console.log(this.user);
    });
  }


}
 }
NavbarController.$inject=['AuthService','usuariosService','$auth'];
 angular.module('palmiGirosApp')
  .component('navbar', {
    templateUrl: 'components/navbar/navbar.html',
    controller: NavbarController,
    controllerAs: 'vm'
  });
