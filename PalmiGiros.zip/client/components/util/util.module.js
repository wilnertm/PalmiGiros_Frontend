'use strict';

angular.module('palmiGirosApp.util', []);
