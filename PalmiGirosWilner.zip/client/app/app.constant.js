(function(angular, undefined) {
  angular.module("palmiGirosApp.constants", [])

.constant("appConfig", {
	"userRoles": [
		"guest",
		"user",
		"admin"
	]
})

;
})(angular);